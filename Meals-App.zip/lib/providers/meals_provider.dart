//meals_provider.dart
//
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:jioo/data/dummy_data.dart';

final mealsProvider = Provider((ref) {
  return dummyMeals;
});
