//filters.dart
//
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../filter_provider.dart';

class FiltersScreen extends ConsumerWidget {
  const FiltersScreen({
    super.key,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final activeFilters = ref.watch(filtersProvider);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Your Filters'),
      ),
      body: Column(
        children: [
          SwitchListTile(
            value: activeFilters[Filter.glutenFree]!,
            onChanged: (isChechked) {
              ref
                  .read(filtersProvider.notifier)
                  .setFilter(Filter.glutenFree, isChechked);
            },
            title: const Text('Glutern-Free',
                style: TextStyle(color: Colors.white, fontSize: 25)),
            subtitle: const Text('Only include Gluten-Free meals'),
            activeColor: Colors.green.shade500,
            contentPadding: EdgeInsets.only(left: 34, right: 22),
          ),
          SwitchListTile(
            value: activeFilters[Filter.lactoseFree]!,
            onChanged: (isChechked) {
              ref
                  .read(filtersProvider.notifier)
                  .setFilter(Filter.lactoseFree, isChechked);
            },
            title: const Text('Lactose-Free',
                style: TextStyle(color: Colors.white, fontSize: 25)),
            subtitle: const Text('Only include Lactosr-Free meals'),
            activeColor: Colors.green.shade500,
            contentPadding: EdgeInsets.only(left: 34, right: 22),
          ),
          SwitchListTile(
            value: activeFilters[Filter.vegetarian]!,
            onChanged: (isChechked) {
              ref
                  .read(filtersProvider.notifier)
                  .setFilter(Filter.vegetarian, isChechked);
            },
            title: const Text('Vegetarian',
                style: TextStyle(color: Colors.white, fontSize: 25)),
            subtitle: const Text('Only include Vegetarian meals'),
            activeColor: Colors.green.shade500,
            contentPadding: EdgeInsets.only(left: 34, right: 22),
          ),
          SwitchListTile(
            value: activeFilters[Filter.vegan]!,
            onChanged: (isChechked) {
              ref
                  .read(filtersProvider.notifier)
                  .setFilter(Filter.vegan, isChechked);
            },
            title: const Text('Vegan',
                style: TextStyle(color: Colors.white, fontSize: 25)),
            subtitle: const Text('Only include Vegan meals'),
            activeColor: Colors.green.shade500,
            contentPadding: EdgeInsets.only(left: 34, right: 22),
          ),
        ],
      ),
    );
  }
}
