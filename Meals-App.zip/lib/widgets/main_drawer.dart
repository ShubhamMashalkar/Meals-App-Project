//main_drawer.dart

import 'package:flutter/material.dart';

class MainDrawer extends StatelessWidget {
  const MainDrawer({super.key, required this.onSelectScreen});

  final void Function(String identifier) onSelectScreen;

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Column(
        children: [
          const DrawerHeader(
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
                gradient: LinearGradient(
              colors: [Colors.red, Colors.brown],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            )),
            child: Row(children: const [
              Icon(
                Icons.fastfood,
                size: 48,
                color: Colors.white,
              ),
              SizedBox(
                width: 20,
              ),
              Text(
                'Cooking up',
                style: TextStyle(color: Colors.white, fontSize: 28),
              )
            ]),
          ),
          ListTile(
            leading: Icon(Icons.restaurant, size: 26),
            title: Text('Meals',
                style: TextStyle(fontSize: 24, color: Colors.white)),
            onTap: () {
              onSelectScreen('meals');
            },
          ),
          ListTile(
            leading: Icon(Icons.settings, size: 26),
            title: Text('Filters',
                style: TextStyle(fontSize: 24, color: Colors.white)),
            onTap: () {
              onSelectScreen('filters');
            },
          )
        ],
      ),
    );
  }
}
