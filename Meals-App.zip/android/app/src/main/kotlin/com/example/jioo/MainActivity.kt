package com.example.jioo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
